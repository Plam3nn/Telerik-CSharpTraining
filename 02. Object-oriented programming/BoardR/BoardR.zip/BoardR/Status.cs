﻿namespace BoardR
{
    public enum Status
    {
        Open = 0,
        ToDo = 1,
        InProgress = 2,
        Done = 3,
        Verified = 4
    }
}
