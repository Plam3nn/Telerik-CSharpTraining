﻿namespace BoardR.Loggers.Contracts
{
    public interface ILogger
    {
        void Log(string value);
    }
}
