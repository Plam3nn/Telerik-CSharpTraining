﻿namespace CosmeticsShop.Models
{
    public enum GenderType
    {
        Men,
        Women,
        Unisex
    }
}
