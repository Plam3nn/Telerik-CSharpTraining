﻿namespace CosmeticsShop.Commands
{
    public enum CommandType
    {
        CreateCategory,
        CreateProduct,
        AddProductToCategory,
        ShowCategory,
    }
}
