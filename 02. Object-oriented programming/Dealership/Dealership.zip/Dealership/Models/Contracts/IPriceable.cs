﻿namespace Dealership.Models.Contracts
{
    public interface IPriceable
    {
        decimal Price { get; }
    }
}
