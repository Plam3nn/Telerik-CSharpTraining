﻿namespace Dealership.Commands.Contracts
{
    public interface ICommand
    {
        string Execute();
    }
}
