﻿namespace Agency.Models.Contracts
{
    public interface IHasId
    {
        int Id { get; }
    }
}
