﻿namespace Agency.Commands.Contracts
{
    public interface ICommand
    {
        string Execute();
    }
}
