﻿namespace Agency.Core.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
