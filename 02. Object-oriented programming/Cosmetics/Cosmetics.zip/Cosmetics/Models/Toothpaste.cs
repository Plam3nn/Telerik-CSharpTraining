﻿using Cosmetics.Helpers;
using Cosmetics.Models.Contracts;
using Cosmetics.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cosmetics.Models
{
    public class Toothpaste : Product, IToothpaste
    {
        private string ingredients;

        public Toothpaste(string name, string brand, decimal price, GenderType gender, string ingredients)
            : base(name, brand, price, gender) 
        {
            this.Ingredients = ingredients;
        }

        public string Ingredients
        {
            get
            {
                return this.ingredients;
            }
            init
            {
                ValidateNullIngredients(value);
                this.ingredients = value;
            }
        }

        public override string ToString()
        {
            var output = new StringBuilder();

            output.AppendLine(this.Print());
            output.AppendLine($" #Ingredients: [{string.Join(", ", this.Ingredients.Split())}]");
            output.Append(" ===");

            return output.ToString();
        }
        private void ValidateNullIngredients(string ingredients)
        {
            if (string.IsNullOrEmpty(ingredients))
            {
                throw new ArgumentNullException($"{nameof(this.Ingredients)} cannot be null or empty.");
            }
        }
    }
}
