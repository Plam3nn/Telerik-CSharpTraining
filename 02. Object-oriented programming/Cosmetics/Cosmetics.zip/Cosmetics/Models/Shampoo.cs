﻿using Cosmetics.Helpers;
using Cosmetics.Models.Contracts;
using Cosmetics.Models.Enums;
using System;
using System.Text;

namespace Cosmetics.Models
{
    public class Shampoo : Product, IShampoo
    {
        private int millilitres;
        private UsageType usage;

        public Shampoo(string name, string brand, decimal price, GenderType gender, int millilitres, UsageType usage)
            : base(name, brand, price, gender)
        {
            this.Millilitres = millilitres;
            this.Usage = usage;
        }

        public int Millilitres
        {
            get
            {
                return this.millilitres;
            }
            init
            {
                ValidationHelper.ValidateNonNegative(value, nameof(this.Millilitres));
                this.millilitres = value;
            }
        }

        public UsageType Usage
        {
            get
            {
                return this.usage;
            }
            init
            {
                ValidateUsage(value);
                this.usage = value;
            }
        }
        
        private void ValidateUsage(UsageType usage)
        {
            if (usage != UsageType.EveryDay
                && usage != UsageType.Medical)
            {
                throw new ArgumentException($"Usage type must be either {UsageType.EveryDay} or {UsageType.Medical}.");
            }
        }

        public override string ToString()
        {
            var output = new StringBuilder();

            output.AppendLine(this.Print());
            output.AppendLine($" #Milliliters: {this.Millilitres}");
            output.AppendLine($" #Usage: {this.Usage}");
            output.Append(" ===");

            return output.ToString();
        }
    }
}
