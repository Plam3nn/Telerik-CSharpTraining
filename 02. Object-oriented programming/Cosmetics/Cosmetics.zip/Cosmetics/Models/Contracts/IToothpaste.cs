﻿namespace Cosmetics.Models.Contracts
{
    public interface IToothpaste
    {
        string Ingredients { get; }
    }
}