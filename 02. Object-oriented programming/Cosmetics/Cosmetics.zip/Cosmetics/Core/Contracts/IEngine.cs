﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cosmetics.Core.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
