﻿using DoublyLinkedListWorkshop;
using System;

class Program
{
    static void Main()
    {
        LinkedList<int> list = new LinkedList<int>();

        list.AddFirst(5);
        list.AddFirst(4);
        list.AddFirst(3);
        list.AddFirst(2);
        list.AddFirst(1);
        ;
    }
}
